Black Mirror is a tool that lets you sync and back up your files easily,
no database or daemon is needed for that. You can call it just like you
would call a "copy" command, and a few handy switches let you alter the
behavior of the program.

Everyone can improve this software just by using the internet shortcuts
to report bugs or request features.


Quick Start
===========

In order to install Black Mirror you will need at least Perl 5 up and
running on your system. Version 5.8.* or up with all Core packages is
recommended. Of course Perl needs to be in your PATH.

Upgrading
---------
When you already have installed Black Mirror and want to update it, just
run the setup command as you would in order to install the software.

Installation on Unixes
----------------------
(Applies to Mac OS X, Linux, ...)
To install, open a command line (Shell on Linux; Terminal on Mac OS X, which
is in your /Applications/Utilities folder) and type in these commands:

	cd <Folder_where_README.txt_is>
	sudo ./setup

Here you will be asked for your root (administrator) password.
And you're done! (In case that didn't work:
	sudo source setup
)

Granted that "/usr/bin" is in your $PATH, you should be able to get the
usage page of Black Mirror by

	blkmror ?

Installation on Microsoft Windows
---------------------------------
To install, open a command prompt (located in the Accessories folder, or
just type [Win]+[R], "cmd", [RETURN])
Then change to the directory (and the drive) where README.txt and the other
files of Black Mirror are. So, type something like:

	X:
	cd ...
	setup <Installation_directory>

After you've put the Installation_directory in your PATH, you should be
able to get the usage page of Black Mirror by

	blkmror ?
