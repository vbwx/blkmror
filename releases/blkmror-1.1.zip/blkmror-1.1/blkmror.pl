# Black Mirror -- Syncs directories and backs up deleted files.
# Version 1.1
# Copyright (C) 2007 Bernhard Waldbrunner

# This program is free software; you can redistribute it and/or modify
# it under the terms of the GNU General Public License as published by
# the Free Software Foundation; either version 2 of the License, or
# (at your option) any later version.
#
# This program is distributed in the hope that it will be useful,
# but WITHOUT ANY WARRANTY; without even the implied warranty of
# MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
# GNU General Public License for more details.
#
# You should have received a copy of the GNU General Public License
# along with this program; if not, write to the Free Software
# Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA


use File::Find;
use File::Copy::Recursive qw(dircopy dirmove);
use File::Spec::Functions;

do {
	$more_args = 0;
	$src = shift or die "A mandatory argument is missing";
	$src eq '?' and help();
	$src eq '!' and version();
	$src eq '--help' and help();
	$src eq '--version' and version();
	if ($src =~ /^-/) {
		$more_args = 1;
		$src =~ /v/ and $is_verbose  = 1;
		$src =~ /q/ and $is_quiet    = 1;
		$src =~ /b/ and $no_backup   = 1;
		$src =~ /h/ and $do_hidden   = 1;
		$src =~ /r/ and $no_readonly = 1;
		$src =~ /t/ and $do_temp     = 1;
		$src =~ /l/ and $no_log      = 1;
		$src =~ /p/ and $is_pretend  = 1;
		$src =~ /T/ and $do_tree     = 1;
		$src =~ /s/ and $is_strict   = 1;
		unless ($src =~ /^-[vqbhrtlpTs]+$/) {
			print STDERR "Invalid switch handed over!\nType 'blkmror ?' to get"
				. " help.\n\n";
			exit(255);
		}
		($is_verbose && $is_quiet) and die 'Contradictory switches (q & v)';
		($is_quiet && $is_pretend) and die 'Contradictory switches (q & p)';
		($do_tree && $is_pretend) and print STDERR
			"Switch -p is ineffective when -T is active!\n";
	} else {
		$target = shift or die "A mandatory argument is missing";
	}
} while ($more_args);
$is_pretend ||= $do_tree;

BEGIN {
	if ($^O eq "MSWin32") {
		$is_Windows = 1;
		eval 'use Win32::File qw(GetAttributes SetAttributes HIDDEN)';
	} elsif ($^O eq "darwin") {
		$is_MacOSX = 1;
		eval 'use Unicode::Normalize qw(compose NFD)';
		eval 'use MacOSX::File::Info';
		eval 'use MacOSX::File::Copy';
	}
	unless ($is_MacOSX) {
		eval 'use File::Copy';
	}
}

if ($is_Windows) {
	$src =~ s!["\\/]+$!!; $src =~ s/^"//;
	$target =~ s!["\\/]+$!!; $target =~ s/^"//;
} else {
	$src =~ s!/+$!!;
	$target =~ s!/+$!!;
}
-e $src or die "Source directory doesn't exist";
-d $src or die "Source is no directory";
(-e $target && !-d $target) and die "Target is no directory";
-e $target or mkdir canonpath($target) or die "Can't create target directory";

$Hidden = '...'; $src = catfile($src, ''); $target = catfile($target, '');
$Size = $Added = $Synced = $Unlinked = $Archived = $Backup = $Entries = 0;
print "This would be done:\n" if ($is_pretend && !$do_tree);
$| = 1 unless ($do_tree || $is_quiet);

if (-f catfile($src, '.BM_Tree') && !$do_tree
   && !-f catfile($target, '.BM_Tree')) {
	open(TREE, catfile($src, '.BM_Tree')) or
		die "Can't open <.BM_Tree>";
	while (<TREE>) {
		(/^\/[^\/]/ || /\t/) and die "<.BM_Tree> contains illegal characters";
		next if (/^\s*\/\// || /^\s*$/);
		s/\r?\n$//;
		if ($is_MacOSX) {
			$t = NFD($_); utf8::encode($t);
			push @Tree, $t;
		} else {
			push @Tree, $_;
		}
	}
	close TREE or warn "Can't close <.BM_Tree>";

	find( sub {
		unless ($_ eq '.' || $_ eq '..' || $File::Find::name =~ /^\Q$Hidden\E/
		       || $_ eq '.BM_Tree' || ($do_temp ? 0 : $_ =~ /\.te?mp$/i)
		       || ($no_log ? $_ =~ /\.log$/i : 0)
		       || ($no_readonly ? (!-W $File::Find::name) : 0)
		       || ($no_backup ? ($_ =~ /\w*~\w*$/ || $_ =~ /^~\$?/
		       || $_ =~ /\.bak$/i || $_ =~ /\.backup$/i) : 0)) {
			if ($is_Windows) {
				GetAttributes($File::Find::name, $Attr);
				(!$do_hidden && ($Attr & HIDDEN)) and
					$Hidden = $File::Find::name;
			} else {
				(!$do_hidden && $_ =~ /^\./) and $Hidden = $File::Find::name;
			}
			if ($is_MacOSX) {
				%info = MacOSX::File::Info->get($File::Find::name)->flags();
				($no_readonly && $info{-locked}) and
					$Hidden = $File::Find::name;
			}
			unless ($File::Find::name eq $Hidden) {
				$Path = canonpath($File::Find::name);
				$Path =~ s{^\Q$target\E}{}i;
				$Path =~ s{\\}{/}g if $is_Windows;
				$Path .= '/' if (-d $File::Find::name);
				$Path_src = catfile($src, $Path);
				$Path_target = catfile($target, $Path);
				$tree_contains = popElem(\@Tree, $Path);
				if (-e $Path_src && -M $Path_src < -M $Path_target
				    && $tree_contains) {
					if (-f $Path_target || -f $Path_src) {
						$Synced++;
						$Size += -s $Path_src;
						if ($is_verbose) {
							print "* $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							if (-d $Path_target) {
								remtree($Path_target);
							} else {
								unlink $Path_target or
									die "Can't delete <$Path_target>";
							}
							if (-d $Path_src) {
								mkdir $Path_target or die
									"Can't create directory <$Path_target>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							} elsif (-f $Path_src) {
								copy($Path_src, $Path_target) or
									warn "Can't copy <$Path>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							}
						}
					}
				} elsif (!-e $Path_src && !$is_strict) {
					$Archived++;
					$Backup += -s $Path_target;
					if ($tree_contains) {
						print "\n<$Path_src> doesn't exist!" unless $is_quiet;
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_target))[8,9];
							if (-d $Path_target) {
								dircopy($Path_target, $Path_src) or warn
									"Can't copy directory <$Path>";
								utime $atime, $mtime, $Path_src or warn
									"Can't update time stamps of <$Path>";
							} elsif (-f $Path_target) {
								copy($Path_target, $Path_src) or warn
									"Can't copy <$Path>";
								utime $atime, $mtime, $Path_src or warn
									"Can't update time stamps of <$Path>";
							}
						}
					} elsif (!is_archived($Path_src)) {
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_target))[8,9];
							if (-d $Path_target) {
								dirmove($Path_target, $Path_src) or warn
									"Can't move directory <$Path>";
								utime $atime, $mtime, $Path_src or warn
									"Can't update time stamps of <$Path>";
							} elsif (-f $Path_target) {
								move($Path_target, $Path_src) or warn
									"Can't move <$Path>";
								utime $atime, $mtime, $Path_src or warn
									"Can't update time stamps of <$Path>";
							}
						}
					}
				} elsif (!$tree_contains) {
					$Unlinked++;
					if ($is_verbose) {
						print "- $Path\n";
					} elsif (!$is_quiet && !$is_pretend) {
						print '.';
					}
					unless ($is_pretend) {
						if (-d $Path_target) {
							remtree($Path_target);
						} else {
							unlink $Path_target or
								die "Can't delete <$Path_target>";
						}
					}
				}
			}
		}
	}, $target);
	$Hidden = '...';
	for $Path (@Tree) {
		next if (!defined($Path) || $Path eq '' || $Path =~ /\.BM_Tree$/
		        || $Path =~ /^\Q$Hidden\E/ || ($do_temp ? 0 :
		        $Path =~ /\.te?mp$/i) || ($no_log ? $Path =~ /\.log$/i : 0) ||
		        ($no_backup ? ($Path =~ /\w*~\w*$/ ||
		        $Path =~ /[\\\/]~\$?[^\/\\]+$/ || $Path =~ /^~\$?[^\/\\]+/
		        || $Path =~ /\.bak$/i || $Path =~ /\.backup$/i) : 0));
		if ($is_Windows) {
			GetAttributes(catfile($src, canonpath($Path)), $Attr);
			(!$do_hidden && ($Attr & HIDDEN)) and $Hidden = $Path;
		} else {
			(!$do_hidden && ($Path =~ /^\./ || $Path =~ /[\/]\.[^\/]+$/))
				and $Hidden = $Path;
		}
		if ($is_MacOSX) {
			%info =
			MacOSX::File::Info->get(catfile($src, canonpath($Path)))->flags();
			($no_readonly && $info{-locked}) and
				$Hidden = $Path;
		}
		unless ($Path eq $Hidden) {
			$Path_src = catfile($src, $Path);
			$Path_target = catfile($target, $Path);
			if (-e $Path_src) {
				if (-e $Path_target && -M $Path_src < -M $Path_target) {
					if (-f $Path_target || -f $Path_src) {
						$Synced++;
						$Size += -s $Path_src;
						if ($is_verbose) {
							print "* $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							if (-d $Path_target) {
								remtree($Path_target);
							} else {
								unlink $Path_target or
									die "Can't delete <$Path_target>";
							}
							if (-d $Path_src) {
								mkdir $Path_target or die
									"Can't create directory <$Path_target>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							} elsif (-f $Path_src) {
								copy($Path_src, $Path_target) or
									warn "Can't copy <$Path>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							}
						}
					}
				} elsif (!-e $Path_target) {
					if (-d $Path_src) {
						$Added++;
						if ($is_verbose) {
							print "+ $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							mkdir $Path_target or
								die "Can't create directory <$Path_target>";
							utime $atime, $mtime, $Path_target or warn
								"Can't update time stamps of <$Path>";
						}
					} elsif (-f $Path_src) {
						$Added++;
						$Size += -s $Path_src;
						if ($is_verbose) {
							print "+ $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							copy($Path_src, $Path_target) or
								warn "Can't copy <$Path>";
							utime $atime, $mtime, $Path_target or warn
								"Can't update time stamps of <$Path>";
						}
					}
				}
			} else {
				print STDERR "\n<$Path_src> doesn't exist!";
			}
		}
	}
} else {
	unless ($is_pretend && !$do_tree) {
		if (-f catfile($target, '.BM_Tree')) {
			unlink catfile($target, '.BM_Tree') or
				die "Can't delete <.BM_Tree>";
		}
		if ($is_MacOSX) {
			open(TREE, '>'.catfile($target, '._BM_Tree')) or
				die "Can't write to <._BM_Tree>";
		} else {
			open(TREE, '>'.catfile($target, '.BM_Tree')) or
				die "Can't write to <.BM_Tree>";
		}
	}

	find( sub {
		unless ($_ eq '.' || $_ eq '..' || $File::Find::name =~ /^\Q$Hidden\E/
		       || ($do_temp ? 0 : $_ =~ /\.te?mp$/i)
		       || ($no_log ? $_ =~ /\.log$/i : 0)
		       || ($no_readonly ? (!-W $File::Find::name) : 0)
		       || ($no_backup ? ($_ =~ /\w*~\w*$/ || $_ =~ /^~\$?/
		       || $_ =~ /\.bak$/i || $_ =~ /\.backup$/i) : 0)) {
			if ($is_Windows) {
				GetAttributes($File::Find::name, $Attr);
				(!$do_hidden && ($Attr & HIDDEN)) and
					$Hidden = $File::Find::name;
			} else {
				(!$do_hidden && $_ =~ /^\./) and $Hidden = $File::Find::name;
			}
			if ($is_MacOSX) {
				%info = MacOSX::File::Info->get($File::Find::name)->flags();
				($no_readonly && $info{-locked}) and
					$Hidden = $File::Find::name;
			}
			unless ($File::Find::name eq $Hidden) {
				$Path = canonpath($File::Find::name);
				$Path =~ s{^\Q$src\E}{}i;
				$Path =~ s{\\}{/}g if $is_Windows;
				$Path .= '/' if (-d $File::Find::name);
				print TREE $Path . "\n" unless ($is_pretend && !$do_tree);
				$Entries++;
				return if $do_tree;
				$Path_src = catfile($src, $Path);
				$Path_target = catfile($target, $Path);
				if (-e $Path_target && -M $Path_src < -M $Path_target) {
					if (-f $Path_target || -f $Path_src) {
						$Synced++;
						if (-d $Path_src || -d $Path_target) {
							$Backup += -s $Path_target;
							$Archived++;
						}
						$Size += -s $Path_src;
						if ($is_verbose) {
							print "* $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							if (-d $Path_target || -d $Path_src) {
								archive($Path_target);
							} else {
								unlink $Path_target or
									die "Can't delete <$Path_target>";
							}
							if (-d $Path_src) {
								mkdir $Path_target or die
									"Can't create directory <$Path_target>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							} elsif (-f $Path_src) {
								copy($Path_src, $Path_target) or
									warn "Can't copy <$Path>";
								utime $atime, $mtime, $Path_target or warn
									"Can't update time stamps of <$Path>";
							}
						}
					}
				} elsif (!-e $Path_target) {
					if (-d $Path_src) {
						$Added++;
						if ($is_verbose) {
							print "+ $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							mkdir $Path_target or
								die "Can't create directory <$Path_target>";
							utime $atime, $mtime, $Path_target or warn
								"Can't update time stamps of <$Path>";
						}
					} elsif (-f $Path_src) {
						$Added++;
						$Size += -s $Path_src;
						if ($is_verbose) {
							print "+ $Path\n";
						} elsif (!$is_quiet && !$is_pretend) {
							print '.';
						}
						unless ($is_pretend) {
							($atime, $mtime) = (stat($Path_src))[8,9];
							copy($Path_src, $Path_target) or
								warn "Can't copy <$Path>";
							utime $atime, $mtime, $Path_target or warn
								"Can't update time stamps of <$Path>";
						}
					}
				}
			}
		}
	}, $src);

	if ($is_MacOSX) {
		unless ($is_pretend && !$do_tree) {
			close TREE or warn "Can't close <._BM_Tree>";
			open(TREE8, "<:utf8", catfile($target, "._BM_Tree")) or
				die "Can't read <._BM_Tree>";
			open(TREE, ">:encoding(latin1)", catfile($target, ".BM_Tree")) or
				die "Can't write to <.BM_Tree>";
			while (<TREE8>) {
				print TREE compose($_);
			}
			close TREE8 or warn "Can't close <._BM_Tree>";
			unlink catfile($target, '._BM_Tree') or
				die "Can't delete <._BM_Tree>";
		}
	}
	print "\n.BM_Tree file updated." unless $is_pretend;
	SetAttributes(catfile($target, '.BM_Tree'), HIDDEN) if $is_Windows;
	unless ($is_pretend && !$do_tree) {
		close TREE or warn "Can't close <.BM_Tree>";
	}
}

unless ($is_quiet) {
	if ($do_tree) {
		print "$Entries lines written to <".catfile($target, ".BM_Tree").">.";
	} else {
		$_size = $_backup = "B";
		if ($Size >= 1024) {
			$Size /= 1024; $_size = "KB";
		}
		if ($Size >= 1024) {
			$Size /= 1024; $_size = "MB";
		}
		if ($Size >= 1024) {
			$Size /= 1024; $_size = "GB";
		}
		if ($Backup >= 1024) {
			$Backup /= 1024; $_backup = "KB";
		}
		if ($Backup >= 1024) {
			$Backup /= 1024; $_backup = "MB";
		}
		if ($Backup >= 1024) {
			$Backup /= 1024; $_backup = "GB";
		}
		print "\n$Added file(s) added, $Unlinked file(s) removed, "
			. "$Synced file(s) synchronized;\n";
		printf "%.1f $_size copied, $Archived file(s) backed up "
			. "(%.1f $_backup)", $Size, $Backup;
	}
	print "\n";
}
exit;

sub help {
	print <<'END';
usage:
blkmror [SWITCHES] SRC_DIR TARGET_DIR
    If TARGET_DIR contains a file called <.BM_Tree>, Black Mirror copies all
    new or changed files found in SRC_DIR to TARGET_DIR and updates the global
    index file <.BM_Tree>.
    If SRC_DIR contains the global index file, Black Mirror will copy, delete
    or update all files necessary in order to adjust TARGET_DIR to SRC_DIR.
    In this case both directories are being synchronized. Also, files found in
    TARGET_DIR that haven't existed before in SRC_DIR will be archived to the
    directory with <.BM_Tree> (i.e., the backup device).
    If no directory contains <.BM_Tree>, it will be created in TARGET_DIR.
    If both directories contain an index file, they will just be kept in sync,
    without deleting any files or directories.
blkmror !
    Displays version info.

SWITCHES:
    -q  Quiet operation.
    -v  Verbose.
    -h  Include hidden files and directories.
    -t  Include temporary files.
    -r  Exclude read-only files and directories.
    -b  Exclude backup files.
    -l  Exclude log files.
    -p  Pretend: Don't copy or delete anything.
    -T  Only create the .BM_Tree file, don't copy or delete anything.
    -s  Strict: Only forward backups (from SRC_DIR to TARGET_DIR), if at all.

END
	exit(0);
}

sub version {
	print "Black Mirror: Version 1.1\n"
		. "Copyright (C) 2007 Bernhard Waldbrunner\n\n";
	print <<'END';
   This program is free software; you can redistribute it and/or modify
   it under the terms of the GNU General Public License as published by
   the Free Software Foundation; either version 2 of the License, or
   (at your option) any later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, Inc., 51 Franklin St, Fifth Floor, Boston, MA  02110-1301  USA

END
	print "See LICENSE.txt for more information.\n\n";
	exit(0);
}

## remtree($dir)
## dir: directory to remove recursively
sub remtree {
	my $root = canonpath(shift);
	local *ROOT;

	opendir ROOT, $root or die "Can't open directory <$root>";
	while ($_ = readdir ROOT) {
		next if /^\.\.?$/;
		my $path = catfile($root, $_);
		if (-d $path) {
			remtree($path);
		} else {
			unlink $path or die "Can't delete <$path>";
		}
	}
	closedir ROOT or warn "Can't close directory <$root>";
	rmdir $root or warn "Can't remove directory <$root>";
}

## archive($file)
## file: Path of file or directory to rename (with backup number)
sub archive {
	my $file = canonpath(shift);

	my $i = 1;
	if (-d $file || !($file =~ /.+\.\w+$/)) {
		while (-e ($file."~$i")) {
			$i++;
		}
		rename($file, $file."~$i") or die "Can't rename <$file/>";
	} else {
		my($f, $ext) = ($file =~ /(.+)\.(\w+)$/);
		while (-e ($f."~$i.".$ext)) {
			$i++;
		}
		rename($file, $f."~$i.".$ext) or die "Can't rename <$file>";
	}
}

## popElem(\@array, $elem)
## RETURNS 1 if the element has been found (and deleted)
## array: reference to an array of elements where the element should be seeked
## elem: element to be seeked and deleted if present
sub popElem {
	$array = shift or die 'popElem(): \@array missing';
	$elem = shift or die 'popElem(): $elem missing';

	for ($i = 0; $i < scalar @$array; $i++) {
		next unless defined($array->[$i]);
		if ($array->[$i] eq $elem) {
			delete $array->[$i] or die "popElem(): Can't delete element $i";
			return 1;
		}
	}
	return 0;
}

## is_archived($file)
## RETURNS 1 if the file has been archived
## file: File (without backup number) to be checked
sub is_archived {
	$file = canonpath(shift);

	if (-d $file || !($file =~ /.+\.\w+$/)) {
		return 1 if -e ($file."~1");
	} else {
		my($f, $ext) = ($file =~ /(.+)\.(\w+)$/);
		return 1 if -e ($f."~1.".$ext);
	}
	return 0;
}
