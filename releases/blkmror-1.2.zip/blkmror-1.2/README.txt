Black Mirror is a utility that lets you sync and back up your files easily,
no database or daemon is needed for that. You can call it just like you
would call a "copy" command, and a few handy switches let you alter the
behavior of the program.

Everyone can improve this software just by using the internet shortcut
"Services". (It takes you to SourceForge.net where you can post bug reports or
feature requests and the like.)

-------------------------------------------------------------------------------

Installation of this software is very easy due to the provided setup scripts
for Unixes and Microsoft Windows.

For more information on installing or updating Black Mirror, please read the
file INSTALL.txt.
